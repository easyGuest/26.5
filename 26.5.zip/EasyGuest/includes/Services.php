<?php

require_once('init/init.php');
global $session;
global $database; 
$user=$session->get_user_id();

$isSend=true;

if(isset($_POST["submit"])){
    
if($_POST["Towels"]){
    $Towels = $_POST["Towels"];
    $prodName="Towels";
        $isSend=true;
    $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$Towels."','".$user."');";
    if(!$database->query($sql)){
       $isSend=false; 
        
    }

    
}
if($_POST["shaving"]){
        $shaving = $_POST["shaving"];
        $prodName="shaving";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$shaving."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}}
if($_POST["dental"]){
        $dental = $_POST["dental"];
        $prodName="dental";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$dental."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}}
if($_POST["shampoo"]){
        $shampoo = $_POST["shampoo"];
        $prodName="shampoo";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$shampoo."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}
    
}
if($_POST["Soap"]){
        $Soap = $_POST["Soap"];
        $prodName="Soap";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$Soap."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}

}
if($_POST["Pillow"]){
        $Pillow = $_POST["Pillow"];
        $prodName="Pillow";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$Pillow."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}}
if($_POST["blanket"]){
        $blanket = $_POST["blanket"];
        $prodName="blanket";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$blanket."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}}
if($_POST["sheets"]){
        $sheets = $_POST["sheets"];
        $prodName="sheets";
        $sql="INSERT INTO houseKeeping (name,unitsNum, user) VALUES ('".$prodName."','".$sheets."','".$user."');";
        if(!$database->query($sql)){
           $isSend=false; 
}}
    if($isSend==true)
    {
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
    }
    else
    {
    echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
  echo '}, 1000);</script>';
    } 
}
   
   
   
if(isset($_POST["clean"])){
    $type=$_POST["type"];


    if($_POST["time"])
        $Time = $_POST["time"];
        
    if($_POST["note"])    
        $note = $_POST["note"];
        
    $sql="INSERT INTO Maintance (date,user, notes,Type) VALUES ('".$Time."','".$user."','".$note."','".$type."');";
        if(!$database->query($sql)){
        echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Something went wrong","Your request has not confirmed","error");';
  echo '}, 1000);</script>';
        }
        else{
              echo '<script type="text/javascript">';
  echo 'setTimeout(function () { swal("Your order has been sent","Thank you for your patience","success");';
  echo '}, 1000);</script>';
            
            
        }
    
}


?>



<!DOCTYPE html>
<html lang="en" class="no-js">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=.5"> 
		<title>EasyGuest - housekeeping</title>
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="Codrops" />
		<link rel="shortcut icon" href="../favicon.ico"> 
		<link rel="stylesheet" type="text/css" href="../css/default.css" />
		<link rel="stylesheet" type="text/css" href="../css/component.css" />
        	<link rel="stylesheet" type="text/css" href="../css/normalize.css" />
        
 
		<link rel="stylesheet" type="text/css" href="../css/demo.css" />
		<link rel="stylesheet" type="text/css" href="../css/icons.css" />
		<link rel="stylesheet" type="text/css" href="../css/style5.css" />
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <link rel='stylesheet prefetch' href='https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css'>


	</head>
	<body>

			<header>
                   <nav id="bt-menu" class="bt-menu">
                    <a href="#" class="bt-menu-trigger"><span>Menu</span></a>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Digital key</a></li>
                        <li><a href="#">Services</a></li>
                        <li><a href="#">Restaurant</a></li>
                        <li><a href="#">Transportation</a></li>
                        <li><a href="#">Check out</a></li>

                    </ul>
                </nav>

			</header>
<form method="post" action="Services.php">

  <div id="id01" class="w3-modal" style="z-index:1;
">
      <div class="w3-container">
  <div class="page-wrapper">
  <div class="page-view">
      <h1 class="head">Select Bath products</h1>

     <p class="head">Towels (max 5):</p>
    <div class="counter" data-counter data-max="5" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="Towels" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
    <p class="head">shaving kit (max 3):</p>
    <div class="counter" data-counter data-max="3" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="shaving" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
	    <p class="head">dental kit (max 3):</p>
    <div class="counter" data-counter data-max="3" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="dental" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
	    <p class="head">shampoo (max 5):</p>
    <div class="counter" data-counter data-max="5" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="shampoo" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
		    <p class="head">Soap (max 5):</p>
    <div class="counter" data-counter data-max="5" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="Soap"  type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
	
	<button class="btn raise" type="submit" name="submit" onclick="document.getElementById('id01').style.display='none';">Send</button>
		<button class="btn raise" type="button" onclick="document.getElementById('id01').style.display='none';">close</button>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>


</div>

      </div>
    </div>
  </div>
  
  </form>
  <form method="post" action="Services.php">

    <div id="id02" class="w3-modal" style="z-index:1;
">
	
      <div class="w3-container">
  <div class="page-wrapper">
  <div class="page-view">
      <h1 class="head">Select Bath products</h1>

    <p class="head">Pillow (max 5):</p>
    <div class="counter" data-counter data-max="5" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="Pillow" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
    <p class="head">blanket  (max 3):</p>
    <div class="counter" data-counter data-max="10" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="blanket" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>
	    <p class="head">bed sheets (max 3):</p>
    <div class="counter" data-counter data-max="10" data-min="0">
      <button type="button" class="btn raise" data-count="down">-</button>
      <input name="sheets" type="text" class="counter text">
      <button type="button" class="btn raise" data-count="up">+</button>
    </div>

	
	<button class="btn raise"type="submit" name="submit" onclick="document.getElementById('id02').style.display='none'; myFunction();">Send</button>
		<button class="btn raise" type="button" onclick="document.getElementById('id02').style.display='none';">close</button>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

<script>

</script>
</div>

      </div>
    </div>
  </div>
    </form>

    <form method="post" action="Services.php">

    <div id="id03" class="w3-modal" style="z-index:1;
">
	
      <div class="w3-container">
  <div class="page-wrapper">
  <div class="page-view">
      <h2 class="head">Select clean time</h2>

  <div class="cent"">
  <input type="datetime-local" value="2018-08-19T13:00:00" id="example-datetime-local-input" name="time" step="3600" style="box-shadow: 2px 5px;"><br><br>
</div>
	<textarea rows="4" cols="50" placeholder="Pleasr write notes..." name="note"style="box-shadow: 2px 5px;"></textarea>

	<input type="hidden" name="type" value="clean">
	<button class="btn raise" type="submit" name="clean" onclick="document.getElementById('id03').style.display='none';">Send</button>
		<button class="btn raise" type="button" onclick="document.getElementById('id03').style.display='none';">close</button>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</div>

      </div>
    </div>
  </div>
    </form>

<form method="post" action="Services.php">

    <div id="id04" class="w3-modal" style="z-index:1;
">
	
      <div class="w3-container">
  <div class="page-wrapper">
  <div class="page-view">
      <h2 class="head">Select Laundary time</h2>

  <div class="col-10">
  <input style="box-shadow: 2px 5px;" id="asd" class="cent" type="datetime-local" value="2018-08-19T13:00:00" id="example-datetime-local-input" name="time" step="3600"><br><br>
</div>

    <input type="hidden" name="type" value="Laundary">

	<textarea rows="4" cols="50" placeholder="Pleasr write notes..." name="note"style="box-shadow: 2px 5px;"></textarea>

	
	<button  class="btn raise" type="submit" name="clean" onclick="document.getElementById('id04').style.display='none';">Send</button>
		<button  class="btn raise" type="button" onclick="document.getElementById('id04').style.display='none';">close</button>
<script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

</div>

      </div>
    </div>
  </div>
    </form>

<div class="tabs">
  <div class="tab-2">
    <label for="tab2-1">Housekeeping</label>
    <input id="tab2-1" name="tabs-two" type="radio" checked="checked">
    <div>
        			<ul class="grid cs-style-3">
				<li>
					<figure>
						<img src="../images/toothbrush.png" alt="img04">
						<figcaption>
							<h3>Bath products</h3>
							<span>Towels, shaving kit, dental kit etc.</span>
							<a href="#" onclick="document.getElementById('id01').style.display='block'">Order</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="../images/make%20up%20room.png" alt="img01">
						<figcaption>
							<h3>Makeup my room</h3>
                            <span>housekeeping to clean your room</span>

							<a href="#" onclick="document.getElementById('id03').style.display='block'">Order</a>
						</figcaption>
					</figure>
				</li>
<li>
					<figure>
						<img src="../images/sheets.png" alt="img03">
						<figcaption>
							<h3>Bed sheets</h3>
							<span>Pillow, blanket and bed sheet</span>
							<a href="#" onclick="document.getElementById('id02').style.display='block'">Order</a>
						</figcaption>
					</figure>
				</li>
				<li>
					<figure>
						<img src="../images/laundary.png" alt="img06">
						<figcaption>
							<h3>Laundary service</h3>
							<span>service to clean your clothes</span>
						<a href="#" onclick="document.getElementById('id04').style.display='block'">Order</a>
						</figcaption>
					</figure>
				</li>
			</ul>

    </div>
  </div>
  <div class="tab-2">
    <label for="tab2-2">Maintenance</label>
    <input id="tab2-2" name="tabs-two" type="radio">
    <div>
        
        <?php require 'checkbox.php';?>

    </div>
  </div>
</div>
        
        

	</body>
	
        <script src="../js/classie.js"></script>
	<script src="../js/borderMenu.js"></script>
<script src="../js/service.js"></script>
		<script src="../js/toucheffects.js"></script>
		
		<script src="../js/modernizr.custom.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
  <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

</html>