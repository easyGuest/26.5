<?php

define('DB_HOST','localhost');
define('DB_USER','roird_guest');
define('DB_PASS','12345');
define('DB_NAME','roird_EasyGuest');

?>