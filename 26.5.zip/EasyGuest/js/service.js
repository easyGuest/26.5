(function() {
  var Counter;

  Counter = (function() {
    'use-strict';
    var _counter, _element, _init_value, _max_count, _min_count;

    class Counter {
      constructor(element) {
        this.bindEvents = this.bindEvents.bind(this);
        this._element = $(element);
        this._counter = this._element.find('.counter');
        this._min_count = this._element.attr('data-min');
        this._max_count = this._element.attr('data-max');
        this._init_value = this._counter.val() || this._min_count;
        this.bindEvents();
        this.renderInitialValue();
      }

      renderInitialValue() {
        this._counter.val(this._init_value);
        return this.resolveButtonState(this._element);
      }

      bindEvents() {
        var self;
        self = this;
        return this._element.on('click', function(event) {
          var $counter, $target, $targetType, $this, count, currentCount;
          $this = $(this);
          $target = $(event.target);
          $targetType = $target.attr('data-count');
          $counter = $this.find('.counter');
          count = $counter.val();
          currentCount = count ? parseInt(count) : 0;
          if ($targetType === 'up') {
            self.incrementCounterUp($counter, currentCount);
          } else if ($targetType === 'down') {
            self.incrementCounterDown($counter, currentCount);
          } else {
            return false;
          }
          return self.resolveButtonState($this);
        });
      }

      incrementCounterUp($counter, currentCount) {
        if (currentCount + 1 > this._max_count) {
          return false;
        } else {
          currentCount = currentCount + 1;
          $counter.val(currentCount);
        }
      }

      incrementCounterDown($counter, currentCount) {
        if (currentCount - 1 < this._min_count) {
          $counter.val(0);
        } else {
          currentCount = currentCount - 1;
          $counter.val(currentCount);
        }
      }

      resolveButtonState($this) {
        var $downButton, $upButton, count, currentCount;
        $upButton = $this.find('[data-count="up"]');
        $downButton = $this.find('[data-count="down"]');
        count = $this.find('.counter').val();
        currentCount = count ? parseInt(count) : 0;
        if (currentCount + 1 > this._max_count) {
          $upButton.addClass('disabled');
        } else {
          $upButton.removeClass('disabled');
        }
        if (currentCount - 1 < this._min_count) {
          $downButton.addClass('disabled');
        } else {
          $downButton.removeClass('disabled');
        }
      }

    };

    _element = null;

    _counter = null;

    _min_count = null;

    _max_count = null;

    _init_value = null;

    return Counter;

  }).call(this);

  this.Counter = Counter;

  if ($('[data-counter]').length > 0) {
    $('[data-counter]').each(function(index, element) {
      return new Counter(element);
    });
  }

}).call(this);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiPGFub255bW91cz4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFBQSxNQUFBOztFQUFNO0lBQ0o7OztJQURGLE1BQUEsUUFBQTtNQVNFLFdBQWEsQ0FBQyxPQUFELENBQUE7WUFjYixDQUFBLGlCQUFBLENBQUE7UUFiRSxJQUFDLENBQUEsUUFBRCxHQUFlLENBQUEsQ0FBRSxPQUFGO1FBQ2YsSUFBQyxDQUFBLFFBQUQsR0FBZSxJQUFDLENBQUEsUUFBUSxDQUFDLElBQVYsQ0FBZSxVQUFmO1FBQ2YsSUFBQyxDQUFBLFVBQUQsR0FBZSxJQUFDLENBQUEsUUFBUSxDQUFDLElBQVYsQ0FBZSxVQUFmO1FBQ2YsSUFBQyxDQUFBLFVBQUQsR0FBZSxJQUFDLENBQUEsUUFBUSxDQUFDLElBQVYsQ0FBZSxVQUFmO1FBQ2YsSUFBQyxDQUFBLFdBQUQsR0FBZSxJQUFDLENBQUEsUUFBUSxDQUFDLEdBQVYsQ0FBQSxDQUFBLElBQW1CLElBQUMsQ0FBQTtRQUVuQyxJQUFDLENBQUEsVUFBRCxDQUFBO1FBQ0EsSUFBQyxDQUFBLGtCQUFELENBQUE7TUFSVzs7TUFVYixrQkFBb0IsQ0FBQSxDQUFBO1FBQ2xCLElBQUMsQ0FBQSxRQUFRLENBQUMsR0FBVixDQUFjLElBQUMsQ0FBQSxXQUFmO2VBQ0EsSUFBQyxDQUFBLGtCQUFELENBQW9CLElBQUMsQ0FBQSxRQUFyQjtNQUZrQjs7TUFJcEIsVUFBWSxDQUFBLENBQUE7QUFDVixZQUFBO1FBQUEsSUFBQSxHQUFPO2VBRVAsSUFBQyxDQUFBLFFBQVEsQ0FBQyxFQUFWLENBQWEsT0FBYixFQUFzQixRQUFBLENBQUMsS0FBRCxDQUFBO0FBQ3BCLGNBQUEsUUFBQSxFQUFBLE9BQUEsRUFBQSxXQUFBLEVBQUEsS0FBQSxFQUFBLEtBQUEsRUFBQTtVQUFBLEtBQUEsR0FBZSxDQUFBLENBQUUsSUFBRjtVQUNmLE9BQUEsR0FBZSxDQUFBLENBQUUsS0FBSyxDQUFDLE1BQVI7VUFDZixXQUFBLEdBQWUsT0FBTyxDQUFDLElBQVIsQ0FBYSxZQUFiO1VBQ2YsUUFBQSxHQUFlLEtBQUssQ0FBQyxJQUFOLENBQVcsVUFBWDtVQUNmLEtBQUEsR0FBZSxRQUFRLENBQUMsR0FBVCxDQUFBO1VBQ2YsWUFBQSxHQUFrQixLQUFILEdBQWMsUUFBQSxDQUFTLEtBQVQsQ0FBZCxHQUFtQztVQUVsRCxJQUFHLFdBQUEsS0FBZSxJQUFsQjtZQUNFLElBQUksQ0FBQyxrQkFBTCxDQUF3QixRQUF4QixFQUFrQyxZQUFsQyxFQURGO1dBQUEsTUFFSyxJQUFHLFdBQUEsS0FBZSxNQUFsQjtZQUNILElBQUksQ0FBQyxvQkFBTCxDQUEwQixRQUExQixFQUFvQyxZQUFwQyxFQURHO1dBQUEsTUFBQTtBQUdILG1CQUFPLE1BSEo7O2lCQUtMLElBQUksQ0FBQyxrQkFBTCxDQUF3QixLQUF4QjtRQWZvQixDQUF0QjtNQUhVOztNQW9CWixrQkFBb0IsQ0FBQyxRQUFELEVBQVcsWUFBWCxDQUFBO1FBQ2xCLElBQUcsWUFBQSxHQUFlLENBQWYsR0FBbUIsSUFBQyxDQUFBLFVBQXZCO0FBQ0UsaUJBQU8sTUFEVDtTQUFBLE1BQUE7VUFHRSxZQUFBLEdBQWUsWUFBQSxHQUFlO1VBQzlCLFFBQVEsQ0FBQyxHQUFULENBQWEsWUFBYixFQUpGOztNQURrQjs7TUFRcEIsb0JBQXNCLENBQUMsUUFBRCxFQUFXLFlBQVgsQ0FBQTtRQUNwQixJQUFHLFlBQUEsR0FBZSxDQUFmLEdBQW1CLElBQUMsQ0FBQSxVQUF2QjtVQUNFLFFBQVEsQ0FBQyxHQUFULENBQWEsQ0FBYixFQURGO1NBQUEsTUFBQTtVQUdFLFlBQUEsR0FBZSxZQUFBLEdBQWU7VUFDOUIsUUFBUSxDQUFDLEdBQVQsQ0FBYSxZQUFiLEVBSkY7O01BRG9COztNQVF0QixrQkFBb0IsQ0FBQyxLQUFELENBQUE7QUFDbEIsWUFBQSxXQUFBLEVBQUEsU0FBQSxFQUFBLEtBQUEsRUFBQTtRQUFBLFNBQUEsR0FBWSxLQUFLLENBQUMsSUFBTixDQUFXLG1CQUFYO1FBQ1osV0FBQSxHQUFjLEtBQUssQ0FBQyxJQUFOLENBQVcscUJBQVg7UUFDZCxLQUFBLEdBQVEsS0FBSyxDQUFDLElBQU4sQ0FBVyxVQUFYLENBQXNCLENBQUMsR0FBdkIsQ0FBQTtRQUNSLFlBQUEsR0FBa0IsS0FBSCxHQUFjLFFBQUEsQ0FBUyxLQUFULENBQWQsR0FBbUM7UUFFbEQsSUFBRyxZQUFBLEdBQWUsQ0FBZixHQUFtQixJQUFDLENBQUEsVUFBdkI7VUFDRSxTQUFTLENBQUMsUUFBVixDQUFtQixVQUFuQixFQURGO1NBQUEsTUFBQTtVQUdFLFNBQVMsQ0FBQyxXQUFWLENBQXNCLFVBQXRCLEVBSEY7O1FBS0EsSUFBRyxZQUFBLEdBQWUsQ0FBZixHQUFtQixJQUFDLENBQUEsVUFBdkI7VUFDRSxXQUFXLENBQUMsUUFBWixDQUFxQixVQUFyQixFQURGO1NBQUEsTUFBQTtVQUdFLFdBQVcsQ0FBQyxXQUFaLENBQXdCLFVBQXhCLEVBSEY7O01BWGtCOztJQTNEdEI7O0lBR0UsUUFBQSxHQUFjOztJQUNkLFFBQUEsR0FBYzs7SUFDZCxVQUFBLEdBQWM7O0lBQ2QsVUFBQSxHQUFjOztJQUNkLFdBQUEsR0FBYzs7Ozs7O0VBcUVoQixJQUFJLENBQUMsT0FBTCxHQUFlOztFQUVmLElBQUcsQ0FBQSxDQUFFLGdCQUFGLENBQW1CLENBQUMsTUFBcEIsR0FBNkIsQ0FBaEM7SUFDRSxDQUFBLENBQUUsZ0JBQUYsQ0FBbUIsQ0FBQyxJQUFwQixDQUF5QixRQUFBLENBQUMsS0FBRCxFQUFRLE9BQVIsQ0FBQTthQUN2QixJQUFJLE9BQUosQ0FBWSxPQUFaO0lBRHVCLENBQXpCLEVBREY7O0FBOUVBIiwic291cmNlc0NvbnRlbnQiOlsiY2xhc3MgQ291bnRlclxuICAndXNlLXN0cmljdCdcbiAgXG4gIF9lbGVtZW50ICAgID0gbnVsbFxuICBfY291bnRlciAgICA9IG51bGxcbiAgX21pbl9jb3VudCAgPSBudWxsXG4gIF9tYXhfY291bnQgID0gbnVsbFxuICBfaW5pdF92YWx1ZSA9IG51bGxcblxuICBjb25zdHJ1Y3RvcjogKGVsZW1lbnQpIC0+XG4gICAgQF9lbGVtZW50ICAgID0gJChlbGVtZW50KVxuICAgIEBfY291bnRlciAgICA9IEBfZWxlbWVudC5maW5kKCcuY291bnRlcicpXG4gICAgQF9taW5fY291bnQgID0gQF9lbGVtZW50LmF0dHIoJ2RhdGEtbWluJylcbiAgICBAX21heF9jb3VudCAgPSBAX2VsZW1lbnQuYXR0cignZGF0YS1tYXgnKVxuICAgIEBfaW5pdF92YWx1ZSA9IEBfY291bnRlci52YWwoKSB8fCBAX21pbl9jb3VudFxuXG4gICAgQGJpbmRFdmVudHMoKVxuICAgIEByZW5kZXJJbml0aWFsVmFsdWUoKVxuXG4gIHJlbmRlckluaXRpYWxWYWx1ZTogLT5cbiAgICBAX2NvdW50ZXIudmFsKEBfaW5pdF92YWx1ZSlcbiAgICBAcmVzb2x2ZUJ1dHRvblN0YXRlKEBfZWxlbWVudCk7XG5cbiAgYmluZEV2ZW50czogPT5cbiAgICBzZWxmID0gdGhpc1xuXG4gICAgQF9lbGVtZW50Lm9uICdjbGljaycsIChldmVudCkgLT5cbiAgICAgICR0aGlzICAgICAgICA9ICQodGhpcylcbiAgICAgICR0YXJnZXQgICAgICA9ICQoZXZlbnQudGFyZ2V0KVxuICAgICAgJHRhcmdldFR5cGUgID0gJHRhcmdldC5hdHRyKCdkYXRhLWNvdW50JylcbiAgICAgICRjb3VudGVyICAgICA9ICR0aGlzLmZpbmQoJy5jb3VudGVyJylcbiAgICAgIGNvdW50ICAgICAgICA9ICRjb3VudGVyLnZhbCgpXG4gICAgICBjdXJyZW50Q291bnQgPSBpZiBjb3VudCB0aGVuIHBhcnNlSW50KGNvdW50KSBlbHNlIDBcblxuICAgICAgaWYgJHRhcmdldFR5cGUgPT0gJ3VwJ1xuICAgICAgICBzZWxmLmluY3JlbWVudENvdW50ZXJVcCAkY291bnRlciwgY3VycmVudENvdW50XG4gICAgICBlbHNlIGlmICR0YXJnZXRUeXBlID09ICdkb3duJ1xuICAgICAgICBzZWxmLmluY3JlbWVudENvdW50ZXJEb3duICRjb3VudGVyLCBjdXJyZW50Q291bnRcbiAgICAgIGVsc2VcbiAgICAgICAgcmV0dXJuIGZhbHNlXG5cbiAgICAgIHNlbGYucmVzb2x2ZUJ1dHRvblN0YXRlKCR0aGlzKTtcblxuICBpbmNyZW1lbnRDb3VudGVyVXA6ICgkY291bnRlciwgY3VycmVudENvdW50KSAtPlxuICAgIGlmIGN1cnJlbnRDb3VudCArIDEgPiBAX21heF9jb3VudFxuICAgICAgcmV0dXJuIGZhbHNlXG4gICAgZWxzZVxuICAgICAgY3VycmVudENvdW50ID0gY3VycmVudENvdW50ICsgMVxuICAgICAgJGNvdW50ZXIudmFsIGN1cnJlbnRDb3VudFxuICAgIHJldHVyblxuXG4gIGluY3JlbWVudENvdW50ZXJEb3duOiAoJGNvdW50ZXIsIGN1cnJlbnRDb3VudCkgLT5cbiAgICBpZiBjdXJyZW50Q291bnQgLSAxIDwgQF9taW5fY291bnRcbiAgICAgICRjb3VudGVyLnZhbCAwXG4gICAgZWxzZVxuICAgICAgY3VycmVudENvdW50ID0gY3VycmVudENvdW50IC0gMVxuICAgICAgJGNvdW50ZXIudmFsIGN1cnJlbnRDb3VudFxuICAgIHJldHVyblxuXG4gIHJlc29sdmVCdXR0b25TdGF0ZTogKCR0aGlzKSAtPlxuICAgICR1cEJ1dHRvbiA9ICR0aGlzLmZpbmQoJ1tkYXRhLWNvdW50PVwidXBcIl0nKVxuICAgICRkb3duQnV0dG9uID0gJHRoaXMuZmluZCgnW2RhdGEtY291bnQ9XCJkb3duXCJdJylcbiAgICBjb3VudCA9ICR0aGlzLmZpbmQoJy5jb3VudGVyJykudmFsKClcbiAgICBjdXJyZW50Q291bnQgPSBpZiBjb3VudCB0aGVuIHBhcnNlSW50KGNvdW50KSBlbHNlIDBcblxuICAgIGlmIGN1cnJlbnRDb3VudCArIDEgPiBAX21heF9jb3VudFxuICAgICAgJHVwQnV0dG9uLmFkZENsYXNzICdkaXNhYmxlZCdcbiAgICBlbHNlXG4gICAgICAkdXBCdXR0b24ucmVtb3ZlQ2xhc3MgJ2Rpc2FibGVkJ1xuXG4gICAgaWYgY3VycmVudENvdW50IC0gMSA8IEBfbWluX2NvdW50XG4gICAgICAkZG93bkJ1dHRvbi5hZGRDbGFzcyAnZGlzYWJsZWQnXG4gICAgZWxzZVxuICAgICAgJGRvd25CdXR0b24ucmVtb3ZlQ2xhc3MgJ2Rpc2FibGVkJ1xuICAgIHJldHVyblxuXG50aGlzLkNvdW50ZXIgPSBDb3VudGVyXG5cbmlmICQoJ1tkYXRhLWNvdW50ZXJdJykubGVuZ3RoID4gMFxuICAkKCdbZGF0YS1jb3VudGVyXScpLmVhY2ggKGluZGV4LCBlbGVtZW50KSAtPlxuICAgIG5ldyBDb3VudGVyKGVsZW1lbnQpXG4iXX0=
//# sourceURL=coffeescript